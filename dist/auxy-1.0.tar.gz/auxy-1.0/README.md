# auxylia
Contiene funciones que ayudan en el análisis electoral
